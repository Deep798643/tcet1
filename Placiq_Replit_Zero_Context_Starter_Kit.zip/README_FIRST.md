# Placiq Replit Starter Kit (context + scripts + verified API demo)

**No private assets, API keys, or production access are included.** This ZIP supplies the zero-context business brief, 8 storyboard-ready scripts, creative motion direction, provisional color tokens and a server-side HeyGen TTS test request. The Replit Agent must BUILD the actual edit pipeline and render MP4 outputs.

Usage:
1. Start a fresh Replit App with an Agent-capable workspace.
2. Paste `REPLIT_MASTER_PROMPT.md` as the initial instruction (or paste the prompt included in the ChatGPT answer).
3. Upload this ZIP and ask Agent to unzip into project root; alternatively create files from the included markdown yourself.
4. Add `OPENROUTER_API_KEY` under Replit **Secrets**, never paste it into chat or code. If unavailable, agent must render music-only previews and accept user-imported audio.
5. Use real screens from https://placiq.in/ or user-approved screen recordings. Don't fake authenticated dashboards. Only use fonts/music/assets you have rights to.
6. Inspect browser studio, MP4s, audio files, SRTs, and contact sheets; approve before posting.

Reference: https://openrouter.ai/heygen/heygen-voice-1-turbo:free. Limited free model listing indicated ending 2026-11-30; verify at runtime. The API returns raw bytes (not JSON) when successful. Requested PCM streams are ~44.1kHz mono for this model, verify before wrapping as WAV.
