# REPLIT AGENT MASTER PROMPT — PLACIQ CREATIVE PRODUCTION STUDIO

You are acting simultaneously as an award-winning motion director, performance creative strategist, film editor, audio producer and full-stack TypeScript engineer. **Your main assignment is to GENERATE FINISHED, DOWNLOADABLE, SCROLL-STOPPING VIDEO ADS for Placiq**, with a simple in-Replit interface for previewing, re-rendering and exporting. This is not a request for a landing page, slide deck, mood board or fictional video generator interface. The job is not complete unless REAL H.264 MP4 files exist on disk and play successfully.

## 0. Assume zero prior knowledge; read this completely

**Company:** Placiq, https://placiq.in/, learner workspace https://learn.placiq.in/, DSA https://learn.placiq.in/dsa-visual/index.html, resume https://resume.placiq.in/. Placiq is an **AI-native Career Intelligence OS for engineering students**. Its promise is **“Your work, connected.”** It joins resume evidence, GitHub projects, DSA practice, guided project development, AI placement guidance, persistent context/memory and role-readiness planning. Users diagnose a skill gap, prioritize, learn, build, collect evidence, present their work and reassess. This is NOT just an ATS checker, course platform, DSA clone or generic career chatbot.

**Real modules:** AI Placement Copilot; PCME persistent context memory; AI Project Builder (guided roadmaps/checkpoints, project-aware tutor); interactive DSA Visualizer with **1,800+ animations** and Socratic tutor; Resume Intelligence 2.0 (ATS, technical recruiter rubric, gaps); GitHub/project evidence and skill passport; Career Navigator (role gaps/action plan); Enterprise Hiring **private preview only**. Do not imply unavailable Enterprise features are generally available.

**Target:** Indian engineering undergraduates, new developers, software developers and AI/ML aspirants. Their pain: lost context across 40 tabs, copy/paste AI advice, half-done tutorial projects, memorized DSA, resume claims without proof, irrelevant courses, GitHub heatmaps that don't explain engineering depth, uncertainty about what to do next.

**Marketing positioning:** Start from audience pain and tension, NOT a narrated catalogue of features. Show how a student's disconnected engineering preparation becomes an explainable body of work. Real outcomes are NOT guaranteed. CTA is https://learn.placiq.in/. Public website https://placiq.in/ contains genuine product visuals.

## 1. Non-negotiable creative standard

Make **premium product cinema** with the speed of elite mobile-first ads. Kinetic typography, deep compositing, shape morphing, graphical metaphors, programmatic animated diagrams, scene-specific transitions, authentic product screen reveals, strong editorial art direction and audio-reactive impact cuts. Reference category: top-tier tech brand/product launches and tasteful motion-design showreels. Be bold, funny when appropriate, energetic, and constantly evolving.

**AVOID:** blank-screen text blinking; one giant sentence sitting for 3 sec; default gradient SaaS cards; glowing brains; rainbow neural networks; silly stock robots; generic B-roll; made-up Placiq interfaces; fake recruiter scores; excessive 'AI AI AI'; unlicensed tracks; monotonous wipes; meaningless zooms; same animation recycled 8 times. No intro logo. 0–0.7 seconds must grab attention. Visual change approximately every 0.4–1.5 sec, with rare deliberate pauses. Keep high legibility, constrained typography and safe areas for Instagram overlays. Motion must visibly express the idea, not merely decorate copy. Do NOT build a slideshow.

**Suggested, not official, art tokens:** near-black #0F1117, warm off-white #F5F2EC, royal blue #3151EE, hot orange-red #FF533B, acid lime #D6FF38. Use heavy licensed/open typeface (Inter Tight/Archivo Black) and mono labels. Avoid gradients; prefer sharp shapes, textures, split frames, masked reveals, code diagrams, orbiting evidence nodes, physical-feeling animated UI. If a real Placiq knitted panda or fox asset is provided, use tastefully; never add glasses or invent logos. Wordmark text 'Placiq' is enough without official SVG.

## 2. Output plan — produce 8 distinct actual ads

Build and render each in 1080×1920 vertical / 30fps / H.264 + AAC, with a music-only preview, and a narration-final if the TTS API is available. Also render ONE 1920×1080 40-second brand film cut or adaptation. Length may shift to fit actual narration, rather than rushing/cutting the speech. Deliver matching cover still, 12–20 scene storyboard contact sheet, dry narration WAV/MP3 when synthesized, background music/SFX stems, SRT captions, caption/post copy, editable Remotion scene source and render manifest. Required concepts:

1. **47 TABS. ZERO CONTEXT.** Browser tab avalanche, five disconnected workflows, repeated AI prompts, then one Placiq connected evidence graph. PCME and connected work payoff.
2. **THE PROJECT GRAVEYARD.** Project-final.zip, final-v2, blank editor, milestone roadmap, real Project Builder screen. Hook funny and brutal.
3. **YOU MEMORIZED THE CODE. NOW HIDE IT.** Animated algorithm arrays, pointers, invariants, speed-ramped execution; genuine DSA Visualizer; 1,800+ animations.
4. **YOUR GITHUB IS GREEN. SO WHAT?** GitHub contribution grid explodes into repo commits, tests, decisions, evidence. No claims that contribution quantity equals skill.
5. **A RESUME IS A CLAIM. SHOW THE WORK.** Resume bullet becomes repo files, architecture diagram, tests and real evidence; Resume Intelligence payoff.
6. **ANOTHER COURSE? FOR WHAT ROLE?** Certificates pile up, collapse into skill-gap map and action plan; Career Navigator.
7. **YOUR AI FORGOT AGAIN.** Repetitive chat introduction recursion, context snippets stitched into persistent memory and Copilot.
8. **YOUR WORK, CONNECTED — BRAND FILM.** 35–50 seconds: diagnose → prioritize → learn → build → evidence → present → reassess. Make it like a brand launch, not tutorial.

Write/edit voice scripts to fit their footage (typically 22–30 sec shorts, 35–50 sec brand film); develop **3 distinct opening hook variants** for each short (text + visual idea), but render the strongest opening by default. Every ad must use its own motion system, color bias, rhythm and visual metaphor. Include a 6–10 sec microcut of the strongest ad if feasible after the main renders. All scripts are included in `scripts/VIDEO_BRIEFS.json` if the ZIP is supplied; otherwise derive scripts directly from these directions.

## 3. Voice: my actual API model

Use OpenRouter speech model **`heygen/heygen-voice-1-turbo:free`** to generate actual VO. This is a text-to-speech model, NOT HeyGen's video/avatars API. Put API key in **Replit Secrets** as `OPENROUTER_API_KEY`. Do not request the key in chat, print it, commit it, put it in client bundles, or call OpenRouter from the browser. Server-side Node only. Endpoint: `POST https://openrouter.ai/api/v1/audio/speech` with Bearer key and JSON fields `model`, `input`, `voice` (start with `nadine`, verify supported voice list), `response_format` (`pcm` explicitly). Example: `{ "model":"heygen/heygen-voice-1-turbo:free", "input":"Your work, connected.", "voice":"nadine", "response_format":"pcm" }`. Success is **audio bytes, not JSON**: check HTTP status, content-type and nonzero payload; do not save HTTP error JSON as an audio file. For this model expect roughly 44.1 kHz mono PCM; inspect response metadata and wrap/convert as 16-bit little-endian WAV using ffmpeg where applicable, never rename PCM to MP3. Store original/raw plus WAV and compressed MP3; store request metadata and duration **without storing keys**. Its free tier is rate-limited and currently advertises an end date of Nov 30, 2026, so handle errors/expiry gracefully. Do NOT silently switch to a paid model.

Before editing final cuts: generate the narration, get its measured duration/waveform via ffprobe, find pauses/phrases, align visual payoffs to spoken clauses; create subtitle phrase timings by alignment or careful timed segmentation. Music should duck under narration and effects should accent scene changes; normalize without clipping. Ask for user Secrets access only if genuinely necessary. If no API key is configured, **still deliver all actual fully edited music-only videos** + all VO-ready scripts, and clearly label the missing step; do not pretend voices were generated. The included `examples/heygen-tts.mjs` is a working-shape start, not a replacement for proper app integration.

## 4. Architecture — REAL producer, not fake interface

Use Node 20+, TypeScript, React, Remotion (`remotion`, `@remotion/renderer`, `@remotion/player`) for programmatic edits, SVG/canvas assets, `ffmpeg`/`ffprobe` for post-processing and validation; `sharp` as needed. Build a lightweight React control room with: project/reel list, editable copy, storyboards, drag/drop assets and real-footage slots, VO generate button, voice/audio preview, composition preview, render progress tied to actual jobs, export/download links and renders manifest. Include pre-rendered outputs even if preview UI fails. Favor Replit-supported package versions, verify environment binaries, install only needed dependencies, avoid paid plugins and don't rely on unavailable GPU or background services. The render action must not claim completion until target file exists and `ffprobe` verifies it.

Project structure:
`src/compositions/*` — each reel has a separate scene graph,
`src/primitives/*` — reusable graph/array/text/kinetic/layout animations,
`src/app/*` — producer preview interface,
`src/lib/tts.ts` — OpenRouter server-only speech requests,
`src/lib/render.ts` — render queue and ffmpeg post-processing,
`assets/real-product/` — downloaded authorized landing-page graphics and imported user captures,
`assets/audio/` — original or clearly licensed score/SFX,
`content/` — scripts, hooks, captions, shot timing,
`output/{01-video,02-voice,03-stems,04-covers,05-storyboards,06-captions,07-source}/` — final deliverables.

Do not attempt to use authenticated Placiq dashboards without explicit access. Collect authentic screenshots by using publicly available https://placiq.in/ imagery where technically permissible; record exactly which images are real screenshots and which are editorial mock graphics. On unavailable pages use abstract editorial motion designs rather than forging a Placiq interface. Never store sensitive student data. Do not access or modify Placiq auth, payments, RLS or backend.

## 5. Music and sound design

Prioritize licensed/creator-owned audio supplied in the project. If none is uploaded, programmatically compose a clean, original high-energy beat bed and sound effects (drums, taps, glitch ticks, punchy impacts) from scratch. Deliver that music stem in WAV plus AAC in MP4; never scrape copyrighted commercial tracks. Cut rhythmically with real beats/hits rather than generating random flashes. Include subtle breaks before punchlines; no overwhelming narration. Peak below clipping; use LUFS-aware level matching where practical.

## 6. Quality and acceptance criteria

1. First create one **fully animated** 15–25 sec proof-of-quality reel and export a real playable MP4; **self-review 12+ sampled frames**, fix weak/sparse moments, then continue.
2. Produce remaining seven videos with clearly differentiated motion grammar; render full outputs as real files, not links to web preview or simulated jobs.
3. Audit vertical dimensions, FPS, duration, presence of video + audio streams, black frames/silent sections, subtitle collision/safe zones, typographic cropping, CTA URL accuracy, scene-to-VO synchronization, and end-card legibility.
4. Also produce a landscape cut of the brand film and at least one variant of the strongest hook.
5. Deliver a `DELIVERY_MANIFEST.md` with truthful statuses: rendered+verified, voice pending, uploaded to Drive, failed, etc. Never mark uploads as successful without connector confirmation.
6. Upload the exports to Google Drive **only if actual authorized Drive OAuth/plugin access is available**. Create a structured `Placiq / Video Studio / Batch 04 /` folder with `01_Final_Videos`, `02_Previews`, `03_Voiceovers`, `04_Music_And_SFX`, `05_Covers`, `06_Captions`, `07_Sources`, `08_Reports`. If Drive access isn't supported, create a downloadable archive with the exact same folder hierarchy and make exports accessible in Replit; explain the limitation clearly. Do not paste or request Google passwords.
7. Final response must show actual playable file paths, cover thumbnails, what was checked, any missing pieces and the run commands. No 'I have completed videos' claim without real files.

## 7. Work sequence — execute, don't just plan

Read context from this prompt and any uploaded starter files. Bootstrap repository; identify render/audio capabilities. Implement scene primitives and one gorgeous animated reference reel. Generate VO when key exists. Render test MP4. **Actually inspect contact sheet/frame snapshots** and upgrade until it is punchy, original and legible. Then batch-generate other concepts, sound, mix, subtitles, thumbnails, source projects and archive. Keep code organized for reuse and provide UI preview. If resource limits block a render, lower preview resolution for iteration, then try full resolution; preserve full render commands. Focus on finishing high-quality assets rather than fancy empty dashboards. Continue without repeated permission questions except true credential blockers.

**The single most important instruction: MAKE THE VIDEOS. Not a beautiful video-generator homepage.**
