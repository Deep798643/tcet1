# PLACIQ — VERIFIED PRODUCT & CREATIVE BRIEF
Reference date: 27 October 2026
Product: https://placiq.in | Learner: https://learn.placiq.in | DSA: https://learn.placiq.in/dsa-visual/index.html | Resume: https://resume.placiq.in

## Identity
Placiq is an **AI-native Career Intelligence OS** for engineering students and early-career developers. It is not a generic courses app, a LeetCode clone, or just placement-preparation question banks. Brand signature: **Your work, connected.** Marketing promise: connect resume evidence, GitHub repositories, interactive DSA practice, guided projects, preparation context and role-readiness signals into a coherent plan and portfolio of proof.

## Audience pain
- Developers juggling 15-50 tabs, losing context across tutors, coding practice, resumes and projects.
- Students memorizing solutions instead of understanding algorithms.
- Tutorial projects abandoned inside folders named final, final-v2 and real-final.
- GitHub contribution heatmaps without a clear explanation of the engineering decisions.
- Many certificates, little role-relevant proof.
- Resume bullet claims unsupported by the depth of the actual work.
- An AI chat that forgets the whole project every session.

## Product proof surfaces (current public marketing site)
- DSA Visualizer: 1,800+ interactive algorithm animations, step-by-step canvas, variables/pointers, Socratic AI Tutor and mental models. Website: https://learn.placiq.in/dsa-visual/index.html
- AI Project Builder: guided build roadmaps, project-aware tutor, knowledge checkpoints, code and debugging assistance.
- Resume Intelligence 2.0: ATS/recruiter rubric and role gap/evidence analysis.
- PCME persistent context: remembers relevant learning context across learner interactions (respect privacy controls).
- Career Navigator / Role Readiness: target-role gaps and prioritized next actions.
- GitHub / project evidence: repo/project detail is used to connect technical work to claims.
- Skill Passport / verified evidence: proof of work should be emphasized, NOT invented outcomes.
- AI Placement Copilot: context-aware guidance.
- Enterprise Hiring: private preview only; **do not** advertise as fully available to all recruiters.
- Site positioning as seen publicly: “Make your engineering proof impossible to ignore.”

## Visual identity
- Premium product cinema, editorial kinetic type, composited real UI, custom shapes and energetic transitions.
- Dominant colors: near-black (#0F1117), off-white (#F5F2EC), electric royal blue (#3151EE), vivid orange-red (#FF533B), acid lime (#D6FF38) as occasional contrasts. Treat as production palette, **not official verified brand tokens**.
- Strong variable/condensed typography (Inter, Space Grotesk, Archivo Black, or licensed/open fonts). Use bold type + geometric visual grammar; no default gradients.
- Product mascot motifs, if used: plush knitted panda in royal-blue hoodie reading "Placiq"; fox in cream hoodie with backpack. NO glasses. Do not fabricate photorealistic mascot if genuine assets unavailable.
- No gradients, glowing AI brains, blurry orbs, floating stock people, unrelated robot imagery, plain text blinking on blank canvases, generic SaaS UI hallucinations, or unsupported statistics.

## Verified claim guardrails
- Use 1,800+ DSA animations when appropriate.
- Do not imply resume score predicts job placement, promise guaranteed interviews, promise instant hiring, or claim a measured conversion lift without data.
- No invented recruiter testimonials, fake UI recordings, fake dashboards, made-up customer counts or student outcomes.
- Public marketing page may include feature screenshots; actual authenticated user screens require uploaded or approved assets. Explicitly mark editorial visuals as illustrations.
- No alteration to real Placiq backend, auth, billing, or production websites. This project is an offline marketing studio only.

## Primary CTA
“Explore Placiq” / “Your work, connected.” / https://learn.placiq.in
