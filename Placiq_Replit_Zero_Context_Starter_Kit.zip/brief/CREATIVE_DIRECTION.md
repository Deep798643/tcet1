# CREATIVE DIRECTION — NO SLOP

## Goal
Create legitimately scroll-stopping, high-craft Placiq ads that could run on Instagram Reels, YouTube Shorts and LinkedIn. They must feel closer to high-end sports/product launch graphics than to a PowerPoint promo.

## Creative mechanics
- 0.0–0.7 sec: shocking, visually legible pain-point hook. NEVER start with logo.
- 0.7–3.0 sec: visual escalate conflict, not explanatory text. Use sound cuts, an obvious visual metaphor.
- 3–12 sec: meaningfully evolving 2D/2.5D motion systems. Kinetic type should interact with actual graphics, not just flicker.
- 12–21 sec: 1–3 genuine Placiq interface glimpses integrated with purposeful tracking masks, magnifiers, highlights, then a clear payoff.
- Last 1–2 sec: sparse brand resolve, one CTA. Different compositions for each ad.
- Prefer 0.4–1.6 sec motion changes, with deliberate 1.5–2 sec breathable moments, rather than random cuts or constant shaking.
- Typography, framing, graphics and contrast must remain readable on 390px-width phones. Ensure subtitle safe zone and no hidden crucial information behind Instagram UI.
- Use 12–20 visual events per 20–30 sec short, mixing cuts and continuity. No white flash epilepsy-like strobing.

## Distinct motion treatments
1. 47 tabs cascading, recursing and merging into a connected path.
2. Code text assembles into moving algorithm states and pointers; highlight invariant and decisions.
3. GitHub contribution squares become repository files, commit diff and architectural decision nodes.
4. Courses/certificate stack tumbles into a role-gap radar / segmented readiness view — illustrative until real UI proof.
5. Project-final-v2 file avalanche turns into a four-step roadmap and real browser-based builder capture.
6. Resume claim sentence breaks into code evidence, repo details, then verified project story.
7. “AI forgot again” typed prompts loop until a thread of remembered context stitches across scenes.
8. 40-second brand mini-film: diagnose → prioritize → learn → build → evidence → present → reassess.

## Music / SFX
- Original/licensed stems only. If no audio asset exists: procedural drum/synth groove generated with Web Audio offline or FFmpeg (no commercial songs). Do not pretend generated track is an existing licensed song.
- Beat markers from the real music stem must align edits, with purposeful whooshes, hard impacts, mouse clicks and UI ticks; duck music under VO by ~12–18 dB and normalize final audio safely.
- Animate visuals after synthesizing narration (voice-first edit), using accurate measured waveform/duration rather than guesswork.
- Render music-only and final-with-VO files separately, plus dry WAV voice stems.

## Export and tests
1080x1920 H.264, 30fps, AAC, 44.1/48kHz; 1920x1080 30fps for landscape film; reasonable bitrate; `ffprobe` QA on each MP4, audio not silent, last scene visible, intro hook within first second, no clipped titles or unwanted black frames. Render contact sheet/still thumbnails for review. Must finish real files, not just UI or README.
