// Minimal VERIFIED-REQUEST-shape example for OpenRouter HeyGen Voice Turbo free.
// npm package installation not required; Node 20+ fetch, fs and child_process.
// Set OPENROUTER_API_KEY in Replit Secrets. `node examples/heygen-tts.mjs`.
// Saves 44.1kHz mono raw PCM and converts it to a playable WAV using FFmpeg.
// Check output content-type, format and sample rate before assuming success.
import fs from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import path from 'node:path';
const key=process.env.OPENROUTER_API_KEY;
if (!key) {console.error('Set OPENROUTER_API_KEY using Replit Secrets, not in code.'); process.exit(2);}
const model='heygen/heygen-voice-1-turbo:free';
const script=process.argv.slice(2).join(' ')||'What if your career preparation actually remembered you? Your work, connected. Placiq.';
if (script.length>5000) {console.error('Text exceeds model 5000-char limit');process.exit(2);}
const res=await fetch('https://openrouter.ai/api/v1/audio/speech',{
  method:'POST',
  headers:{Authorization:`Bearer ${key}`,'Content-Type':'application/json','HTTP-Referer':'https://placiq.in','X-Title':'Placiq Creative Studio'},
  body:JSON.stringify({model,input:script,voice:'nadine',response_format:'pcm'})
});
if (!res.ok){console.error('TTS HTTP',res.status,(await res.text()).slice(0,500));process.exit(1);}
const contentType=(res.headers.get('content-type')||'').toLowerCase();
const bytes=Buffer.from(await res.arrayBuffer());
if (bytes.length<100 || contentType.includes('json') || bytes[0]===123){console.error('Invalid audio stream',contentType,bytes.toString('utf8',0,250));process.exit(1);}
await fs.mkdir('generated',{recursive:true});
let input='generated/voice.pcm';let ffmpegInput=[];
if (bytes.toString('ascii',0,4)==='RIFF'){input='generated/voice.wav';ffmpegInput=['-i',input];}
else if (contentType.includes('mpeg')||bytes.toString('ascii',0,3)==='ID3'){input='generated/voice.mp3';ffmpegInput=['-i',input];}
else {ffmpegInput=['-f','s16le','-ar','44100','-ac','1','-i',input];}
await fs.writeFile(input,bytes);
const result=spawnSync('ffmpeg',['-y',...ffmpegInput,'-ar','48000','-ac','1','generated/voice-final.wav'],{stdio:'inherit'});
if (result.status!==0) process.exit(result.status||1);
console.log('Voice generated:',path.resolve('generated/voice-final.wav'),'generation-id',res.headers.get('x-generation-id'));
